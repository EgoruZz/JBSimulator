//
//  GameScene.swift
//  TerminalGame
//
//  Created by Egor S. Sergeev on 13.04.2022.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    private var lastUpdateTime : TimeInterval = 0
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
    override func sceneDidLoad() {
        
        
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        
    }
}
