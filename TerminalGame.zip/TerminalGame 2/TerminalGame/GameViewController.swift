//
//  GameViewController.swift
//  TerminalGame
//
//  Created by Egor S. Sergeev on 13.04.2022.
//

import UIKit
import SpriteKit
import GameplayKit
import GameController
import CoreMotion
import AVFoundation

class GameViewController: UIViewController {
    
    @IBOutlet weak var terminalLbl: UILabel!
    @IBOutlet weak var terminalCodeField: UITextView!
    @IBOutlet weak var terminalRootField: UITextView!
    
    var importComm : UILabel!
    var jcsComm : UILabel! // importCommands
    
    var binaryImport : UILabel!
    
    var importArray = [String]()
    var rootArray = [String]()
    var errorArray = [String]() // Arrays
    
    var firstBranch = true // Branches
    
    var errorImport : UILabel! // Errors
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addErrors()
        addImportCommands()
        setupArray()
        setupRootBinary()
        
        terminalCodeField.delegate = self
        terminalRootField.delegate = self
        
    }
    
    
    
    @IBAction func terminalEnterBtn(_ sender: Any) {
        
        while firstBranch == true {
            
            if terminalCodeField.text == importArray[0] + " " + importArray[1] {
                
                firstBranch = false
                
            } else if terminalCodeField.text != importArray[0] + " " + importArray[1] {
                
                terminalCodeField.text = errorArray[0]
                
            }
        }
        
        
    }
    
    
    func addImportCommands() {
        
        importComm = UILabel()
        importComm.text = "import"
        
        jcsComm = UILabel()
        jcsComm.text = "JailCreaterStudio"
        
    }
    
    func setupRootBinary() {
        
        
        
    }
    
    func setupArray() {
        
        importArray = [String]()
        importArray.append(importComm.text!) // 0
        importArray.append(jcsComm.text!) // 1
        
        
        
        errorArray = [String]()
        errorArray.append(errorImport.text!) // 0
        
        
    }
    
    func addErrors() {
        
        errorImport = UILabel()
        errorImport.text = "This import not found"
        
    }
    
    
    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}

extension GameViewController : UITextViewDelegate {
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        terminalCodeField.resignFirstResponder()
        terminalRootField.resignFirstResponder()
        return true
    }
}
