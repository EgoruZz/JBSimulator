//
//  GameViewController.swift
//  JBSimulator
//
//  Created by Egor S. Sergeev on 23.03.2022.
//

import UIKit
import SpriteKit
import GameplayKit
import Foundation

enum gameType {
    case gamesow
}


class GameViewController: UIViewController {
    
    @IBOutlet weak var simLbl: UILabel!
    @IBOutlet weak var ofLbl: UILabel!
    @IBOutlet weak var jbStartLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }

    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    
    @IBAction func startBtn(_ sender: Any) {
        
        moveToGame(game: .gamesow)
        
    }
    
    @IBAction func terminalBtn(_ sender: Any) {
        
        moveToTerminal()
        
    }
    
    @IBAction func manualBtn(_ sender: Any) {
        
        moveToManual()
        
    }
    
    func moveToGame(game : gameType) {
        let gameVC = self.storyboard?.instantiateViewController(withIdentifier: "gameVC") as! ViewController
        
        currentGameType = game

        self.navigationController?.pushViewController(gameVC, animated: true)
    }
    
    func moveToTerminal() {
        
        let terminalVC = self.storyboard?.instantiateViewController(withIdentifier: "terminalVC") as! TerminalViewController
        self.navigationController?.pushViewController(terminalVC, animated: true)
        
    }
    
    func moveToManual() {
        
        let manualVC = self.storyboard?.instantiateViewController(withIdentifier: "manualVC") as! ManualViewController
        self.navigationController?.pushViewController(manualVC, animated: true)
        
    }
    
}
