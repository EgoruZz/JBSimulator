//
//  TerminalViewController.swift
//  JBSimulator
//
//  Created by Egor S. Sergeev on 23.03.2022.
//

import UIKit
import Foundation
import GameplayKit
import GameController
import SpriteKit
import CoreMotion
import AVFoundation

class TerminalViewController: UIViewController {
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var codeField: UITextView!
    @IBOutlet weak var rootField: UITextView!
    @IBOutlet weak var exploitField: UITextView!
    
    var guiLabel:UILabel!
    var debLabel:UILabel!
    var apiLabel:UILabel!
    
    //Commands (labels)
    
    var jbStudioImport:UILabel! // import
    var sudoComm:UILabel!
    var phoneArchComm:UILabel!
    var nasDockerComm:UILabel!
    var darvin:UILabel!
    var hashNumberP8:UILabel! // hashp8
    var hashNumberI7:UILabel! // hashi7
    var hashNumberF3:UILabel! // hashf3
    var mobileSystemOS:UILabel!
    var bootComm:UILabel!
    var mobileModel:UILabel!
    var rootArray:UILabel!
    var packageComm:UILabel!
    var dataLoad:UILabel! // ~data_load: Cydia
    var sandbox:UILabel! // ~data_load: Cydia{SANDBOX} (download all items of programm)
    var releasedComm:UILabel!
    var fakeControllComm:UILabel!
    var dataSynchronize:UILabel! // ~data_synchronize{@root}
    var repoItem:UILabel! // repo
    var delegateComm:UILabel! // *delegate
    
    
    //Operators (labels)
    
    var operatorLeftSlash:UILabel! // \nasDocker
    var operatorConnection:UILabel! // nas_Docker
    var operatorDoubleSlash:UILabel! // nas || Docker
    var operatorRightSlash:UILabel! // /nasDocker/
    var operatorBit:UILabel! // /nasDocker * root:
    // var operatorDeclaration:UILabel! // nasDocker:
    var operatorCall:UILabel! // ~nasDocker
    
    
    //Aids (labels)
    
    var aidRemake:UILabel! // remake()
    var aidSubstrate:UILabel! // !substrate!
    var aidTo:UILabel! // [to: directory] ^phoneArchive^
    
    // CodeSignatures phones (labels)
    
    var code8PlusInput:UILabel!
    var code8PlusOutput:UILabel!
    var code8PlusDelegate:UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameField.delegate = self
        nameField.text = ""
        
        codeField.delegate = self
        codeField.text = ""
        
        rootField.delegate = self
        rootField.text = ""
        
        exploitField.delegate = self
        exploitField.text = "@exploit:"
        
        guiLabel = UILabel()
        guiLabel.text = "GUI_selection[A8F33NYF6]"
        
        debLabel = UILabel()
        debLabel.text = "DEBIAN["
        
        code8PlusInput = UILabel()
        code8PlusInput.text = "0000 0000 0000 0000"
        
        code8PlusOutput = UILabel()
        code8PlusOutput.text = "a000 a000 a000 a000"
        
        code8PlusDelegate = UILabel()
        code8PlusDelegate.text = "1111 2222 3333 4444"
        
    }
    
    @IBAction func enterBtn(_ sender: Any) {
        
        if nameField.text == nameField.text! {
            
            exploitField.text = "EXPLOIT:\n\n#Prog: \(nameField.text!)\n#Code: \(codeField.text!)\n\nINFO:\n\n#Manual: \(rootField.text!)"
            
        }
    }
    
    @IBAction func gpuButton(_ sender: Any) {
        
        txtSubRootPlus()
        
    }
    
    @IBAction func debButton(_ sender: Any) {
        
        txtDebPlus()
        rootField.text! = "getting DEB..."
        
    }
    
    @IBAction func apiButton(_ sender: Any) {
        
        txtRootPlus()
        
}
    
    @IBAction func mobileBtn(_ sender: Any) {
        
        addMobileModelComm()
        
    }
    
    func txtSubRootPlus() {
        
        if rootField.text! == "Device: iphone8Plus\n\(code8PlusOutput.text!)" {
            codeField.text! = codeField.text! + code8PlusDelegate.text!
            rootField.text! = "Sucessful!"
            
        } else if rootField.text! != "Device: iphone8Plus\n\(code8PlusOutput.text!)" {
            
            rootField.text! = "Error: false data"
            
        }
        
    }
    
    func txtDebPlus() {
        
        // rootField.text! += debLabel.text!
        codeField.text! += mobileModel.text!
        
    }
    
    func txtRootPlus() {
        
        if rootField.text! == "Device:\n\(code8PlusInput.text!)" {
            
            rootField.text! = "\(mobileModel.text!) iphone8Plus\n\(code8PlusOutput.text!)"
        
        } else if rootField.text! != "Device:\n\(code8PlusInput.text!)" {
            
            rootField.text! = "Error: not found Mobile or false signature"
            
        } else if rootField.text! !=
    }
    
    func addCommands() {
        
        jbStudioImport = UILabel()
        jbStudioImport.text = "JailCreaterStudion"
        
        sudoComm = UILabel()
        sudoComm.text = "sudo"
        
        phoneArchComm = UILabel()
        phoneArchComm.text = "^phoneArchive^"
        
        nasDockerComm = UILabel()
        nasDockerComm.text = "nasDocker"
        
        darvin = UILabel()
        darvin.text = "darvin"
        
        hashNumberP8 = UILabel()
        hashNumberP8.text = "hashp8"
        
        hashNumberI7 = UILabel()
        hashNumberI7.text = "hashi7"
        
        hashNumberF3 = UILabel()
        hashNumberF3.text = "hashf3"
        
        mobileSystemOS = UILabel()
        mobileSystemOS.text = "IOS"
        
        bootComm = UILabel()
        bootComm.text = "$Boot"
        
    }
    
    
    
    func addMobileModelComm() {
        
        mobileModel = UILabel()
        mobileModel.text = "Device:"
        rootField.text! = mobileModel.text!
        
    }
    
}

extension TerminalViewController : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

extension TerminalViewController : UITextViewDelegate {
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        codeField.resignFirstResponder()
        rootField.resignFirstResponder()
        return true
    }
}
