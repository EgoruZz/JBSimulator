//
//  ManualViewController.swift
//  JBSimulator
//
//  Created by Egor S. Sergeev on 30.03.2022.
//

import UIKit

class ManualViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }

}
