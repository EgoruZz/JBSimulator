//
//  TerminalViewController.swift
//  JBSimulator
//
//  Created by Egor S. Sergeev on 23.03.2022.
//

import UIKit
import Foundation
import GameplayKit
import GameController
import SpriteKit
import CoreMotion
import AVFoundation

class TerminalViewController: UIViewController {
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var codeField: UITextView!
    @IBOutlet weak var rootField: UITextView!
    @IBOutlet weak var exploitField: UITextView!
    
    
    var debianLabel:UILabel!
    
    // Debs
    
    var deb8Plus:UILabel!
    var packet8Plus:UILabel! // - this file.deb
    
    // CreatorCommnad (labels)
    
    var compressComm:UILabel! // xCompress
    
    // Commands (labels)
    
    var importComm:UILabel! // import
    var jbStudioImport:UILabel! // JailCreaterStudio
    var sudoComm:UILabel!
    var nasDockerComm:UILabel!
    var darvin:UILabel!
    var hashNumberP8:UILabel! // hashp8
    var hashNumberI7:UILabel! // hashi7
    var hashNumberF3:UILabel! // hashf3
    var operationSystem:UILabel!
    var mobileSystemOS:UILabel!
    var bootComm:UILabel!
    var mobileModel:UILabel!
    var rootComm:UILabel!
    var packageComm:UILabel!
    var dataLoad:UILabel! // ~data_load: Cydia
    var sandbox:UILabel! // ~data_load: Cydia{SANDBOX} (download all items of programm)
    var releasedComm:UILabel!
    var fakeControllComm:UILabel!
    var dataSynchronize:UILabel! // ~data_synchronize{@root}
    var repoItem:UILabel! // repo
    var delegateComm:UILabel! // *delegate
    
    
    // Operators (labels)
    
    var operatorConnection:UILabel! // nas_Docker
    var operatorDoubleSlash:UILabel! // nas || Docker
    var operatorRightSlash:UILabel! // /nasDocker
    var operatorBit:UILabel! // /nasDocker * root:
    var operatorDeclaration:UILabel! // nasDocker:
    var operatorCall:UILabel! // ~nasDocker
    var operatorSkobaLeft:UILabel!
    var operatorSkobaRight:UILabel!
    var operatorEquals:UILabel!
    
    
    // Aids (labels)
    
    var aidRemake:UILabel! // remake()
    var aidSubstrate:UILabel! // !substrate!
    var aidTo:UILabel! // [to: directory] ^phoneArchive^
    var aidBlobingRoot:UILabel! // @scrabbingRoot
    var aidTrue:UILabel! // true
    var aidFalse:UILabel! // false
    var aidServer:UILabel! // $server
    
    // CodeSignatures phones (labels)
    
    var code8PlusInput:UILabel!
    var code8PlusOutput:UILabel!
    var code8PlusDelegate:UILabel!
    var code8PlusIOS:UILabel!
    
    // Mobiles (labels)
    
    var mobile8plus:UILabel!
    
    // Archives (labels)
    
    var phoneArch:UILabel!
    var directoryArch:UILabel!
    
    // Processors (labels)
    
    var a11Proc:UILabel!
    
    // Fast text (labels)
    
    var firstFastText:UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addCommands()
        addOperators()
        addSignatures()
        addDebLbl()
        addAid()
        addDirectorys()
        addProcessors()
        addFastText()
        
        nameField.delegate = self
        nameField.text = "Programm name"
        
        codeField.delegate = self
        codeField.text = ""
        
        rootField.delegate = self
        rootField.text = ""
        
        exploitField.delegate = self
        exploitField.text = "@exploit\n\nFirst step:Enter the name and click to Enter"
        
    }
    
    @IBAction func enterBtn(_ sender: Any) {
        
        if nameField.text == nameField.text! && exploitField.text == "@exploit\n\nFirst step:Enter the name and click to Enter" {
            
            exploitField.text = "Programm: \(nameField.text!)"
        
        } else if codeField.text == "\(importComm.text!) \(jbStudioImport.text!)" && exploitField.text == "Programm: \(nameField.text!)" {
            
            exploitField.text = "Programm: \(nameField.text!)\n\n~ Creating a Jailbreak ..."
            codeField.text = ""
        
        } else if codeField.text == "\(sudoComm.text!)" {
            
            exploitField.text = exploitField.text + "Administration:"
            
        } else if codeField.text == "\(sudoComm.text!) \(phoneArch.text!)\(operatorRightSlash.text!)\(nasDockerComm.text!)" && exploitField.text == "Programm: \(nameField.text!)\n\n~ Creating a Jailbreak ..." {
            
            exploitField.text = "Programm: \(nameField.text!)\n\n~ Creating a Jailbreak ...\n~ Administration: entering the archive, launching the nasDocker framework"
                
        } else {
            
            if codeField.text == "\(sudoComm.text!) \(phoneArch.text!)\(operatorRightSlash.text!)\(nasDockerComm.text!)" && exploitField.text != "Programm: \(nameField.text!)\n\n~ Creating a Jailbreak ..." {
                
                exploitField.text = "Error: import not specified"
                
        }
    }
}

    
    @IBAction func gpuButton(_ sender: Any) {
        
        txtSubRootPlus()
        
    }
    
    @IBAction func debButton(_ sender: Any) {
        
        txtGettingDeb()
        
    }
    
    @IBAction func apiButton(_ sender: Any) {
        
        txtRootCompare()
        
}
    
    @IBAction func mobileBtn(_ sender: Any) {
        
        addMobileModelComm()
        
        if rootField.text == "$server\(operatorDeclaration.text!) \(aidBlobingRoot.text!) \(operatorDoubleSlash.text!) \(directoryArch.text!)\nPaste your device (click to Mobile button)" {
            
            rootField.text = "$server\(operatorDeclaration.text!) \(aidBlobingRoot.text!) \(operatorDoubleSlash.text!) \(directoryArch.text!)\nDevice: \(a11Proc.text!)"
            
        } else if rootField.text != "$server\(operatorDeclaration.text!) \(aidBlobingRoot.text!) \(operatorDoubleSlash.text!) \(directoryArch.text!)\nPaste your device (click to Mobile button)" {
            
            rootField.text = "Error: invalide data"
            
        }
        
    }
    
    @IBAction func iosBtn(_ sender: Any) {
        
        checkIOS()
        
    }
    
    func checkIOS() {
        
        if rootField.text == "Device:\n1) processor \(operatorEquals.text!) \(aidTrue.text!)\n2) mobile \(operatorEquals.text!) \(aidTrue.text!)\n3) ios \(operatorEquals.text!) \(aidFalse.text!)\n\nCheck ios:\n\(code8PlusIOS.text!)" {
            
            firstFastText.text = "Signature:\n\n\(code8PlusDelegate.text!)\nIOS: 15 (19H17)"
            codeField.text! = codeField.text! + firstFastText.text!
            
        } else if rootField.text != "Device:\n1) processor \(operatorEquals.text!) \(aidTrue.text!)\n2) mobile \(operatorEquals.text!) \(aidTrue.text!)\n3) ios \(operatorEquals.text!) \(aidFalse.text!)\n\nCheck ios:\n\(code8PlusIOS.text!)" {
            
            rootField.text = "Error: false syntaxis"
            
        }
        
    }
    
    func txtSubRootPlus() {
        
        if rootField.text! == "Device: \(a11Proc.text!), Iphone8Plus\n\(code8PlusOutput.text!)" {
            
            codeField.text! = codeField.text! + firstFastText.text!
            
            rootField.text! = "Device:\n1) processor \(operatorEquals.text!) \(aidTrue.text!)\n2) mobile \(operatorEquals.text!) \(aidTrue.text!)\n3) ios \(operatorEquals.text!) \(aidFalse.text!)\n\nCheck ios:"
            
        } else if rootField.text! != "Device: \(a11Proc.text!), Iphone8Plus\n\(code8PlusOutput.text!)" {
            
            rootField.text! = "Error: false data"
            
        }
        
    }
    
    func txtGettingDeb() {
        
        if rootField.text == "\(packageComm.text!)\(operatorDeclaration.text!) \(debianLabel.text!) \(operatorSkobaLeft.text!)\(deb8Plus.text!)\(operatorSkobaRight.text!)\n\(code8PlusDelegate.text!)" {
            
            rootField.text = "\(packet8Plus.text!)\n\nCopy this command and paste next to Package: with space!"
            
        } else if rootField.text != "\(packageComm.text!)\(operatorDeclaration.text!) \(debianLabel.text!) \(operatorSkobaLeft.text!)\(deb8Plus.text!)\(operatorSkobaRight.text!)\n\(code8PlusDelegate.text!)" {
            
            rootField.text = "Error: syntaxis"
            
        }
        
    }
    
    func txtRootCompare() {
        
        if rootField.text! == "$server\(operatorDeclaration.text!) \(aidBlobingRoot.text!) \(operatorDoubleSlash.text!) \(directoryArch.text!)\nDevice: \(a11Proc.text!)\n\(code8PlusInput.text!)" {
            
            rootField.text! = "\(mobileModel.text!), Iphone8Plus\n\(code8PlusOutput.text!)"
        
        } else if rootField.text! != "$server\(operatorDeclaration.text!) \(aidBlobingRoot.text!) \(operatorDoubleSlash.text!) \(directoryArch.text!)\nDevice: \(a11Proc.text!)\n\(code8PlusInput.text!)" {
            
            rootField.text! = "Error: not found Mobile or false signature"
            
        }
    }
    
    func addCommands() {
        
        importComm = UILabel()
        importComm.text = "Import"
        
        jbStudioImport = UILabel()
        jbStudioImport.text = "JailCreaterStudio"
        
        sudoComm = UILabel()
        sudoComm.text = "$sudo"
        
        phoneArch = UILabel()
        phoneArch.text = "^phoneArchive^"
        
        nasDockerComm = UILabel()
        nasDockerComm.text = "nasDocker"
        
        darvin = UILabel()
        darvin.text = "darvin"
        
        hashNumberP8 = UILabel()
        hashNumberP8.text = "hashp8"
        
        hashNumberI7 = UILabel()
        hashNumberI7.text = "hashi7"
        
        hashNumberF3 = UILabel()
        hashNumberF3.text = "hashf3"
        
        operationSystem = UILabel()
        operationSystem.text = "operation_system"
        
        mobileSystemOS = UILabel()
        mobileSystemOS.text = "IOS"
        
        bootComm = UILabel()
        bootComm.text = "$Boot"
        bootComm.textColor = SKColor.green
        
        mobile8plus = UILabel()
        mobile8plus.text = "Iphone8Plus"
        mobileModel = UILabel()
        mobileModel.text = "Device:"
        
        rootComm = UILabel()
        rootComm.text = "§root"
        
        packageComm = UILabel()
        packageComm.text = "Package"
        
    }
    
    func addOperators( ){
        
        operatorConnection = UILabel()
        operatorConnection.text = "_"
        
        operatorDoubleSlash = UILabel()
        operatorDoubleSlash.text = "||"
        
        operatorRightSlash = UILabel()
        operatorRightSlash.text = "/"
        
        operatorBit = UILabel()
        operatorBit.text = "*"
        
        operatorDeclaration = UILabel()
        operatorDeclaration.text = ":"
        
        operatorCall = UILabel()
        operatorCall.text = "~"
        
        operatorSkobaLeft = UILabel()
        operatorSkobaLeft.text = "["
        
        operatorSkobaRight = UILabel()
        operatorSkobaRight.text = "]"
        
        operatorEquals = UILabel()
        operatorEquals.text = "="
        
    }
    
    func addSignatures() {
        
        code8PlusInput = UILabel()
        code8PlusInput.text = "0000 0000 0000 0000"
        
        code8PlusOutput = UILabel()
        code8PlusOutput.text = "a000 a000 a000 a000"
        
        code8PlusDelegate = UILabel()
        code8PlusDelegate.text = "1111 2222 3333 4444"
        
        code8PlusIOS = UILabel()
        code8PlusIOS.text = "1414 1414 1414 1414"
        
    }
    
    func addAid() {
        
        aidRemake = UILabel()
        aidRemake.text = "remake()"
        
        aidSubstrate = UILabel()
        aidSubstrate.text = "!substrate!"
        
        aidTo = UILabel()
        aidTo.text = "to:"
        
        aidBlobingRoot = UILabel()
        aidBlobingRoot.text = "@blobRoot"
        
        aidTrue = UILabel()
        aidTrue.text = "true"
        
        aidFalse = UILabel()
        aidFalse.text = "false"
        
        aidServer = UILabel()
        aidServer.text = "$server"
        
    }
    
    func addDebLbl() {
        
        debianLabel = UILabel()
        debianLabel.text = "DEBIAN"
        
        deb8Plus = UILabel()
        deb8Plus.text = "88888888"
        
        packet8Plus = UILabel()
        packet8Plus.text = "file.deb"
        
    }
    
    func addDirectorys() {
        
        phoneArch = UILabel()
        phoneArch.text = "^phoneArchive^"
        
        directoryArch = UILabel()
        directoryArch.text = "^directory^"
        
    }
    
    func addProcessors() {
        
        a11Proc = UILabel()
        a11Proc.text = "A11"
        
    }
    
    func addFastText() {
        
        firstFastText = UILabel()
        firstFastText.text = "Signature:\n\n\(code8PlusDelegate.text!)\nIOS: not Found"
        
    }
    
    
    
    func addMobileModelComm() {
        
        if rootField.text == "$server\(operatorDeclaration.text!) \(aidBlobingRoot.text!) \(operatorDoubleSlash.text!) \(directoryArch.text!)" {
            
            mobileModel.text = "Device: \(a11Proc.text!)"
            
            rootField.text = "$server\(operatorDeclaration.text!) \(aidBlobingRoot.text!) \(operatorDoubleSlash.text!) \(directoryArch.text!)\nPaste your device (click to Mobile button)"
            
            // $server: @blobRoot || ^directory^
            // Device:
            
        } else if rootField.text == "$server\(operatorDeclaration.text!) \(aidBlobingRoot.text!) \(operatorDoubleSlash.text!) \(directoryArch.text!)" {
            
            rootField.text = "Error: not found an Archive"
            
        }
    }
    
    
}

extension TerminalViewController : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

extension TerminalViewController : UITextViewDelegate {
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        codeField.resignFirstResponder()
        rootField.resignFirstResponder()
        return true
    }
}
