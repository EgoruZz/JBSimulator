//
//  OneSW.swift
//  JBSimulator
//
//  Created by Egor S. Sergeev on 23.03.2022.
//

import UIKit
import SpriteKit
import GameplayKit

class OneSW: SKScene {
    
    var goLbl:SKLabelNode!
    
    override func didMove(to view: SKView) {
        
        
        
    }
    
    func createGoLbl() {
        
        goLbl = SKLabelNode(text: "Hello")
        goLbl.fontName = "Rockwell"
        goLbl.fontSize = 70
        goLbl.fontColor = SKColor.white
        goLbl.position = CGPoint(x: 0, y: 0)
        self.addChild(goLbl)
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        
    }
    
}
